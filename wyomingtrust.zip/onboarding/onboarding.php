<?php
require_once __DIR__ . '/../api/helpers.php';

// Onboarding IS the registration process - allow both logged-in and logged-out users
// If logged in, skip registration step. If not logged in, Step 2 will include account creation.

// Treat sessions for deleted users as logged-out
$validUserId = get_valid_session_user_id();
$isLoggedIn = $validUserId !== false;
$userId = $isLoggedIn ? (int) $validUserId : 0;
$step = isset($_GET['step']) ? (int) $_GET['step'] : 1;
$trustId = isset($_GET['trust_id']) ? (int) $_GET['trust_id'] : 0;

// If logged in, check email verification (only for logged-in users creating additional trusts)
if ($isLoggedIn) {
    try {
        require_once __DIR__ . '/../api/config.php';
        $db = getDatabase();
        $settings = $db->query('SELECT require_email_verification FROM site_settings WHERE id = 1 LIMIT 1')->fetch();
        $requireVerification = $settings ? (int) $settings['require_email_verification'] : 1;

        if ($requireVerification) {
            $user = $db->prepare('SELECT email_verified FROM users WHERE id = :id LIMIT 1');
            $user->execute([':id' => $userId]);
            $userData = $user->fetch();
            
            if (!$userData || !(int) $userData['email_verified']) {
                header('Location: ../verify-status.php?email=' . urlencode($_SESSION['user_email'] ?? ''));
                exit;
            }
        }
    } catch (Exception $e) {
        error_log('Onboarding email verification check failed: ' . $e->getMessage());
    }
}

$page_title = 'Create Trust - WyomingTrust';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title><?php echo htmlspecialchars($page_title); ?></title>
<script src="https://cdn.tailwindcss.com?plugins=forms,typography"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Lexend:wght@400;500;600;700&display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght@100..700,0..1&display=swap" rel="stylesheet"/>
<script>
    tailwind.config = {
        darkMode: "class",
        theme: {
            extend: {
                colors: {
                    primary: "#F59E0B",
                    "navy-900": "#0F172A",
                    "navy-800": "#1E293B",
                    "background-light": "#F8FAFC",
                    "background-dark": "#0F172A",
                },
                fontFamily: {
                    display: ["Lexend", "sans-serif"],
                    sans: ["Inter", "sans-serif"],
                },
            },
        },
    };
</script>
<style>
    body { font-family: 'Inter', sans-serif; }
    h1, h2, h3, h4 { font-family: 'Lexend', sans-serif; }
    .payment-method-card {
        cursor: pointer;
        transition: all 0.2s;
    }
    .payment-method-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    .payment-method-radio input[type="radio"] {
        appearance: none;
        width: 20px;
        height: 20px;
        border: 2px solid #cbd5e1;
        border-radius: 50%;
        position: relative;
        cursor: pointer;
    }
    .payment-method-radio input[type="radio"]:checked {
        border-color: #F59E0B;
    }
    .payment-method-radio input[type="radio"]:checked::after {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background: #F59E0B;
    }
</style>
</head>
<body class="bg-background-light dark:bg-background-dark text-slate-900 dark:text-slate-100 min-h-screen">
<div class="min-h-screen flex flex-col">
<!-- Header -->
<header class="bg-white dark:bg-navy-900 border-b border-slate-200 dark:border-slate-800 sticky top-0 z-50">
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
<div class="flex justify-between items-center h-14 sm:h-16">
<div class="flex items-center gap-2">
<a href="../index.php" class="flex items-center gap-2">
<div class="bg-primary p-1 sm:p-1.5 rounded-lg">
<span class="material-icons-outlined text-navy-900 font-bold text-base sm:text-lg">account_balance</span>
</div>
<span class="text-lg sm:text-xl font-bold tracking-tight text-navy-900 dark:text-white">Wyoming<span class="text-primary">Trust</span></span>
</a>
</div>
<div class="flex items-center gap-2 sm:gap-4">
<?php if ($isLoggedIn): ?>
<a href="../dashboard/user/dashboard.php" class="hidden sm:inline text-sm text-slate-600 dark:text-slate-400 hover:text-primary">Dashboard</a>
<a href="../api/logout.php" class="text-xs sm:text-sm text-red-600 dark:text-red-400 hover:text-red-700 px-2 sm:px-0">Logout</a>
<?php else: ?>
<a href="../login.php" class="text-xs sm:text-sm text-slate-600 dark:text-slate-400 hover:text-primary px-2 sm:px-0">Sign In</a>
<?php endif; ?>
</div>
</div>
</div>
</header>

<!-- Progress Bar -->
<div class="bg-slate-100 dark:bg-navy-800 border-b border-slate-200 dark:border-slate-700">
<div class="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-3 sm:py-4">
<div class="flex items-center justify-between mb-2 gap-2">
<span class="text-xs sm:text-sm font-medium text-slate-600 dark:text-slate-400 whitespace-nowrap">Step <span id="currentStep"><?php echo $step; ?></span> of 4</span>
<span class="text-xs sm:text-sm font-medium text-slate-600 dark:text-slate-400 truncate text-right" id="stepTitle">Trust Type</span>
</div>
<div class="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-1.5 sm:h-2">
<div id="progressBar" class="bg-primary h-1.5 sm:h-2 rounded-full transition-all duration-300" style="width: <?php echo ($step / 4) * 100; ?>%"></div>
</div>
</div>
</div>

<!-- Main Content -->
<main class="flex-1 max-w-[1200px] mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 sm:py-8 lg:py-12">
<div class="bg-white dark:bg-navy-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 p-4 sm:p-6 lg:p-8">
<div id="onboardingContent">
<!-- Content will be loaded dynamically based on step -->
<div class="text-center py-6 sm:py-10">
<div class="animate-spin rounded-full h-8 w-8 sm:h-12 sm:w-12 border-4 border-primary border-t-transparent mx-auto mb-4"></div>
<p class="text-sm sm:text-base text-slate-600 dark:text-slate-400">Loading...</p>
</div>
</div>
</div>
</main>
</div>

<script>
const currentStep = <?php echo $step; ?>;
const trustId = <?php echo $trustId; ?>;
const isLoggedIn = <?php echo $isLoggedIn ? 'true' : 'false'; ?>;
const steps = [
    { id: 1, title: 'Trust Type', component: 'trustType' },
    { id: 2, title: 'Personal Info', component: 'personalInfo' },
    { id: 3, title: 'Beneficiaries', component: 'beneficiaries' },
    { id: 4, title: 'Review & Payment', component: 'review' }
];

let onboardingData = {
    trust_service_id: null,
    trust_type: '', // 'revocable' or 'irrevocable'
    personal_info: {
        full_name: '',
        email: '',
        street: '',
        city: '',
        state: '',
        zip: ''
    },
    password: '', // Only used when not logged in (registration)
    confirm_password: '', // Only used when not logged in (registration)
    registration_email: '', // Email used for registration (for OTP verification)
    requires_verification: false, // Whether email verification is required
    email_sent: false, // Whether verification email was sent
    beneficiaries: [], // { name, relationship, email, allocation, wallet_address, is_myself }
    payment_method_id: null,
    payment_method: null,
    payment_stage: 'select', // select | details | confirmed
    payment_confirmed: false,
    created_trust_id: null
};

let trustServices = [];

// Persist onboarding state across page reloads between steps
// IMPORTANT: Only persists during active onboarding session, clears when done or abandoned
const ONBOARDING_STORAGE_KEY = 'wyomingtrust_onboarding_v1';
const ONBOARDING_STORAGE_TIMESTAMP_KEY = 'wyomingtrust_onboarding_timestamp';
const ONBOARDING_STORAGE_MAX_AGE = 2 * 60 * 60 * 1000; // 2 hours max age

function clearOnboardingStorage() {
    try {
        sessionStorage.removeItem(ONBOARDING_STORAGE_KEY);
        sessionStorage.removeItem(ONBOARDING_STORAGE_TIMESTAMP_KEY);
    } catch (e) {
        // ignore storage failures
    }
}

function saveOnboardingToStorage() {
    // Only save if we're actively in the onboarding flow (on onboarding.php page)
    if (!window.location.pathname.includes('onboarding.php')) {
        return;
    }
    
    try {
        const dataToSave = {
            ...onboardingData,
            _saved_at: Date.now()
        };
        sessionStorage.setItem(ONBOARDING_STORAGE_KEY, JSON.stringify(dataToSave));
        sessionStorage.setItem(ONBOARDING_STORAGE_TIMESTAMP_KEY, Date.now().toString());
    } catch (e) {
        // ignore storage failures
    }
}

function loadOnboardingFromStorage() {
    // Only load if we're on the onboarding page
    if (!window.location.pathname.includes('onboarding.php')) {
        clearOnboardingStorage();
        return;
    }
    
    // IMPORTANT: Clear storage if user is on step 1 (starting fresh)
    // Only restore data if continuing from step 2, 3, or 4
    const urlParams = new URLSearchParams(window.location.search);
    const stepParam = urlParams.get('step');
    const currentStepNum = stepParam ? parseInt(stepParam, 10) : 1;
    
    if (currentStepNum === 1) {
        // User is starting fresh - clear any old data
        clearOnboardingStorage();
        return;
    }
    
    try {
        const timestamp = sessionStorage.getItem(ONBOARDING_STORAGE_TIMESTAMP_KEY);
        if (timestamp) {
            const age = Date.now() - parseInt(timestamp, 10);
            // Clear if data is too old (stale)
            if (age > ONBOARDING_STORAGE_MAX_AGE) {
                clearOnboardingStorage();
                return;
            }
        }
        
        const raw = sessionStorage.getItem(ONBOARDING_STORAGE_KEY);
        if (!raw) return;
        
        const parsed = JSON.parse(raw);
        if (!parsed || typeof parsed !== 'object') {
            clearOnboardingStorage();
            return;
        }
        
        // Remove internal metadata
        delete parsed._saved_at;
        
        // Merge conservatively to avoid breaking expected shape
        onboardingData = {
            ...onboardingData,
            ...parsed,
            personal_info: {
                ...onboardingData.personal_info,
                ...(parsed.personal_info || {}),
            },
            beneficiaries: Array.isArray(parsed.beneficiaries) ? parsed.beneficiaries : onboardingData.beneficiaries,
        };
    } catch (e) {
        // If parsing fails, clear corrupted data
        clearOnboardingStorage();
    }
}

async function prefillPersonalInfoFromProfile() {
    if (!isLoggedIn) return;
    try {
        const resp = await fetch('../api/user/profile.php');
        const data = await resp.json();
        if (data && data.success && data.user) {
            const name = (data.user.full_name || '').toString();
            const email = (data.user.email || '').toString();
            if (!onboardingData.personal_info) onboardingData.personal_info = {};
            if (!onboardingData.personal_info.full_name && name) onboardingData.personal_info.full_name = name;
            if (!onboardingData.personal_info.email && email) onboardingData.personal_info.email = email;
            if (!onboardingData.registration_email && email) onboardingData.registration_email = email;
            saveOnboardingToStorage();
        }
    } catch (e) {
        console.warn('Could not prefill profile:', e);
    }
}

// Load available trust services from API (filtered for onboarding - only Revocable and Irrevocable)
async function loadTrustServices() {
    try {
        const response = await fetch('../api/trust-services.php?for_onboarding=true');
        const data = await response.json();
        if (data.success && data.services) {
            trustServices = data.services;
        }
    } catch (error) {
        console.error('Failed to load trust services:', error);
    }
}

// Get trust service ID from service_key
function getTrustServiceId(serviceKey) {
    const service = trustServices.find(s => s.service_key === serviceKey);
    return service ? service.id : null;
}

// Get selected trust service details
function getSelectedTrustService() {
    return trustServices.find(s => s.id === onboardingData.trust_service_id);
}

async function loadStep(step) {
    const stepData = steps[step - 1];
    if (!stepData) return;
    
    document.getElementById('currentStep').textContent = step;
    document.getElementById('stepTitle').textContent = stepData.title;
    document.getElementById('progressBar').style.width = ((step / 4) * 100) + '%';
    
    const container = document.getElementById('onboardingContent');
    
    switch(step) {
        case 1:
            container.innerHTML = renderTrustTypeStep();
            break;
        case 2:
            container.innerHTML = renderPersonalInfoStep();
            break;
        case 3:
            // Check if user needs email verification before showing beneficiaries step
            // After registration, user is logged in but may need to verify email
            if (isLoggedIn) {
                try {
                    const response = await fetch('../api/user/profile.php?check_verification=true');
                    const data = await response.json();
                    if (data.success && data.requires_verification && !data.email_verified) {
                        // User needs to verify email - show OTP verification step
                        showOTPVerificationStep();
                        return;
                    }
                } catch (error) {
                    console.error('Error checking verification status:', error);
                    // Continue to beneficiaries step if check fails
                }
            }
            // Ensure there is at least one beneficiary form shown by default
            ensureDefaultBeneficiary();
            container.innerHTML = renderBeneficiariesStep();
            // Attach event listeners after HTML is inserted
            setupBeneficiariesStep();
            break;
        case 4:
            container.innerHTML = renderReviewStep();
            break;
    }
}


function renderTrustTypeStep() {
    const revocableService = trustServices.find(s => s.service_key === 'revocable_living_trust');
    const irrevocableService = trustServices.find(s => s.service_key === 'irrevocable_trust');
    const selectedServiceKey = onboardingData.trust_service_id ? (trustServices.find(s => s.id === onboardingData.trust_service_id)?.service_key || null) : null;
    const revocableId = revocableService ? revocableService.id : null;
    const irrevocableId = irrevocableService ? irrevocableService.id : null;
    
    return `
        <div class="max-w-5xl mx-auto">
            <div class="text-center mb-10">
                <h1 class="text-3xl font-bold text-navy-900 dark:text-white mb-3">Choose Your Trust Type</h1>
                <p class="text-slate-500 dark:text-slate-400 text-lg">Select the type of trust that best fits your needs</p>
            </div>
            <div class="grid md:grid-cols-2 gap-6 mb-10">
                <label class="relative border-2 ${selectedServiceKey === 'revocable_living_trust' ? 'border-primary' : 'border-slate-200 dark:border-slate-700'} rounded-2xl p-6 cursor-pointer hover:border-primary transition-all group h-full flex flex-col">
                    <input class="peer sr-only" name="trust_type" type="radio" value="revocable_living_trust" ${selectedServiceKey === 'revocable_living_trust' ? 'checked' : ''} onchange="selectTrustType('revocable_living_trust', ${revocableId || 'null'})"/>
                    <div class="absolute top-6 right-6 w-6 h-6 rounded-full border-2 ${selectedServiceKey === 'revocable_living_trust' ? 'border-primary bg-primary' : 'border-slate-300 dark:border-slate-600'} transition-colors"></div>
                    <div class="w-14 h-14 bg-primary rounded-xl flex items-center justify-center text-white mb-6 shadow-sm">
                        <span class="material-icons-outlined text-2xl">edit</span>
                    </div>
                    <h3 class="text-xl font-bold text-navy-900 dark:text-white mb-3">Revocable Trust</h3>
                    <p class="text-slate-500 dark:text-slate-400 leading-relaxed mb-6 flex-grow">
                        Flexible and amendable during your lifetime. Retain full control of your assets.
                    </p>
                    <div class="flex items-center text-green-600 dark:text-green-400 font-bold text-sm">
                        <span class="material-icons-outlined text-lg mr-1.5">check_circle</span>
                        100% FREE
                    </div>
                    <div class="absolute inset-0 rounded-2xl border-2 border-transparent ${selectedServiceKey === 'revocable_living_trust' ? 'border-primary' : ''} pointer-events-none"></div>
                </label>
                <label class="relative border-2 ${selectedServiceKey === 'irrevocable_trust' ? 'border-primary' : 'border-slate-200 dark:border-slate-700'} rounded-2xl p-6 cursor-pointer hover:border-primary transition-all group h-full flex flex-col">
                    <input class="peer sr-only" name="trust_type" type="radio" value="irrevocable_trust" ${selectedServiceKey === 'irrevocable_trust' ? 'checked' : ''} onchange="selectTrustType('irrevocable_trust', ${irrevocableId || 'null'})"/>
                    <div class="absolute top-6 right-6 w-6 h-6 rounded-full border-2 ${selectedServiceKey === 'irrevocable_trust' ? 'border-primary bg-primary' : 'border-slate-300 dark:border-slate-600'} transition-colors"></div>
                    <div class="w-14 h-14 bg-primary rounded-xl flex items-center justify-center text-white mb-6 shadow-sm">
                        <span class="material-icons-outlined text-2xl">lock</span>
                    </div>
                    <h3 class="text-xl font-bold text-navy-900 dark:text-white mb-3">Irrevocable Trust</h3>
                    <p class="text-slate-500 dark:text-slate-400 leading-relaxed mb-6 flex-grow">
                        Maximum asset protection and significant tax benefits for your estate.
                    </p>
                    <div class="flex items-center text-green-600 dark:text-green-400 font-bold text-sm">
                        <span class="material-icons-outlined text-lg mr-1.5">check_circle</span>
                        100% FREE
                    </div>
                    <div class="absolute inset-0 rounded-2xl border-2 border-transparent ${selectedServiceKey === 'irrevocable_trust' ? 'border-primary' : ''} pointer-events-none"></div>
                </label>
            </div>
            <div class="bg-blue-50 dark:bg-blue-900/30 rounded-xl p-4 flex items-start space-x-3 text-blue-800 dark:text-blue-100 border border-blue-100 dark:border-blue-800/50">
                <span class="material-icons-outlined text-xl mt-0.5 flex-shrink-0 text-primary dark:text-blue-300">info</span>
                <p class="text-sm leading-relaxed">
                    <span class="font-bold">Not sure?</span> You can change your selection later. Our system will guide you based on your specific needs.
                </p>
            </div>
            <div class="fixed bottom-0 left-0 w-full bg-white dark:bg-navy-800 border-t border-slate-200 dark:border-slate-700 py-4 px-8 z-40 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)]">
                <div class="max-w-7xl mx-auto flex justify-between items-center">
                    <button onclick="handleCancelOrExit(); window.location.href='../index.php'" class="px-6 py-2 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white">Cancel</button>
                    <button onclick="nextStep()" ${onboardingData.trust_service_id ? '' : 'disabled'} id="nextBtn" class="bg-primary hover:opacity-90 text-white font-semibold py-3 px-8 rounded-lg flex items-center shadow-lg transform transition hover:-translate-y-0.5 focus:ring-4 focus:ring-primary/20 disabled:opacity-50 disabled:cursor-not-allowed">
                        Next
                        <span class="material-icons-outlined ml-2 text-lg">arrow_forward</span>
                    </button>
                </div>
            </div>
        </div>
    `;
}

function renderPersonalInfoStep() {
    const pi = onboardingData.personal_info || {};
    return `
        <div class="max-w-[1200px] mx-auto">
            <div class="mb-10">
                <div class="flex flex-col gap-3 max-w-[960px] mx-auto">
                    <div class="flex gap-6 justify-between">
                        <p class="text-navy-900 dark:text-white text-base font-semibold leading-normal">Step 2 of 4: Personal Info</p>
                        <p class="text-navy-900 dark:text-white text-sm font-medium leading-normal">50% Complete</p>
                    </div>
                    <div class="rounded-full bg-slate-200 dark:bg-slate-700 h-2 overflow-hidden">
                        <div class="h-full rounded-full bg-primary transition-all duration-500" style="width: 50%;"></div>
                    </div>
                    <div class="flex justify-between items-center">
                        <p class="text-slate-500 dark:text-slate-400 text-sm font-normal leading-normal italic">Next: Beneficiaries</p>
                    </div>
                </div>
            </div>
            <div class="flex flex-col lg:flex-row gap-10 items-start">
                <div class="flex-1 w-full max-w-[700px]">
                    <div class="mb-8">
                        <h1 class="text-navy-900 dark:text-white text-4xl font-black leading-tight tracking-tight mb-3">Personal Information</h1>
                        <p class="text-slate-500 dark:text-slate-400 text-lg font-normal leading-relaxed">Let's get started with your Wyoming statutory trust. We need a few basic details to identify you as the Grantor.${!isLoggedIn ? ' You will also create your account here.' : ''}</p>
                    </div>
                    <div class="bg-white dark:bg-navy-800 border border-slate-200 dark:border-slate-700 rounded-xl p-8 shadow-sm">
                        <form class="space-y-6" onsubmit="event.preventDefault(); savePersonalInfo();">
                            <div class="flex flex-col gap-2">
                                <label class="text-navy-900 dark:text-slate-200 text-sm font-semibold leading-normal">Full Legal Name</label>
                                <input type="text" id="fullNameInput" value="${escapeHtml(pi.full_name || '')}" placeholder="Johnathan Q. Public" autocomplete="off" class="form-input flex w-full rounded-lg text-navy-900 dark:text-white border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-navy-900 focus:ring-2 focus:ring-primary focus:border-primary h-14 placeholder:text-slate-500 p-4 text-base font-normal" required/>
                                <p class="text-xs text-slate-500">As it appears on your government-issued ID.</p>
                            </div>
                            <div class="flex flex-col gap-2">
                                <label class="text-navy-900 dark:text-slate-200 text-sm font-semibold leading-normal">Email Address</label>
                                <input type="email" id="emailInput" value="${escapeHtml(pi.email || '')}" placeholder="john@example.com" autocomplete="off" class="form-input flex w-full rounded-lg text-navy-900 dark:text-white border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-navy-900 focus:ring-2 focus:ring-primary focus:border-primary h-14 placeholder:text-slate-500 p-4 text-base font-normal" required/>
                            </div>
                            ${!isLoggedIn ? `
                            <div class="border-t border-slate-200 dark:border-slate-700 pt-6 space-y-4">
                                <h3 class="text-navy-900 dark:text-white text-lg font-bold mb-4">Create Your Account</h3>
                                <div class="flex flex-col gap-2">
                                    <label class="text-navy-900 dark:text-slate-200 text-sm font-semibold leading-normal">Password</label>
                                    <div class="relative">
                                        <input type="password" id="passwordInput" placeholder="Enter your password" autocomplete="new-password" class="form-input flex w-full rounded-lg text-navy-900 dark:text-white border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-navy-900 focus:ring-2 focus:ring-primary focus:border-primary h-14 placeholder:text-slate-500 p-4 pr-12 text-base font-normal" required/>
                                        <button type="button" onclick="togglePasswordVisibility('passwordInput', this)" class="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 dark:text-slate-400 hover:text-navy-900 dark:hover:text-white focus:outline-none" aria-label="Toggle password visibility">
                                            <span class="material-icons-outlined text-xl toggle-password-icon">visibility_off</span>
                                        </button>
                                    </div>
                                    <p class="text-xs text-slate-500">Must be at least 8 characters with uppercase, lowercase, number, and special character.</p>
                                </div>
                                <div class="flex flex-col gap-2">
                                    <label class="text-navy-900 dark:text-slate-200 text-sm font-semibold leading-normal">Confirm Password</label>
                                    <div class="relative">
                                        <input type="password" id="confirmPasswordInput" placeholder="Confirm your password" autocomplete="new-password" class="form-input flex w-full rounded-lg text-navy-900 dark:text-white border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-navy-900 focus:ring-2 focus:ring-primary focus:border-primary h-14 placeholder:text-slate-500 p-4 pr-12 text-base font-normal" required/>
                                        <button type="button" onclick="togglePasswordVisibility('confirmPasswordInput', this)" class="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 dark:text-slate-400 hover:text-navy-900 dark:hover:text-white focus:outline-none" aria-label="Toggle password visibility">
                                            <span class="material-icons-outlined text-xl toggle-password-icon">visibility_off</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            ` : ''}
                            <div class="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-800">
                                <label class="text-navy-900 dark:text-slate-200 text-sm font-semibold leading-normal">Primary Physical Address</label>
                                <div class="flex flex-col gap-2">
                                    <input type="text" id="streetInput" value="${escapeHtml(pi.street || '')}" placeholder="Street Address" autocomplete="street-address" class="form-input flex w-full rounded-lg text-navy-900 dark:text-white border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-navy-900 focus:ring-2 focus:ring-primary focus:border-primary h-12 placeholder:text-slate-500 p-4 text-base font-normal" required/>
                                </div>
                                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <input type="text" id="cityInput" value="${escapeHtml(pi.city || '')}" placeholder="City" autocomplete="address-level2" class="form-input rounded-lg text-navy-900 dark:text-white border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-navy-900 focus:ring-2 focus:ring-primary focus:border-primary h-12 placeholder:text-slate-500 p-4 text-base font-normal" required/>
                                    <input type="text" id="stateInput" value="${escapeHtml(pi.state || '')}" placeholder="State/Prov" autocomplete="address-level1" class="form-input rounded-lg text-navy-900 dark:text-white border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-navy-900 focus:ring-2 focus:ring-primary focus:border-primary h-12 placeholder:text-slate-500 p-4 text-base font-normal" required/>
                                    <input type="text" id="zipInput" value="${escapeHtml(pi.zip || '')}" placeholder="ZIP Code" autocomplete="postal-code" class="form-input rounded-lg text-navy-900 dark:text-white border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-navy-900 focus:ring-2 focus:ring-primary focus:border-primary h-12 placeholder:text-slate-500 p-4 text-base font-normal" required/>
                                </div>
                            </div>
                            <div class="pt-6 flex justify-end">
                                <button type="button" onclick="savePersonalInfoAndContinue();" class="flex min-w-[180px] cursor-pointer items-center justify-center rounded-lg h-14 px-6 bg-primary text-white hover:bg-primary/90 transition-all text-base font-bold shadow-md shadow-primary/20">
                                    <span>Continue to Beneficiaries</span>
                                    <span class="material-icons-outlined ml-2 text-sm">arrow_forward</span>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                <aside class="w-full lg:w-[320px] sticky top-24">
                    <div class="bg-white dark:bg-navy-800 border border-slate-200 dark:border-slate-700 rounded-xl p-6 shadow-sm overflow-hidden relative">
                        <div class="absolute -top-12 -right-12 w-32 h-32 bg-primary/5 rounded-full blur-2xl"></div>
                        <div class="relative z-10 flex flex-col gap-6">
                            <div>
                                <h3 class="text-navy-900 dark:text-white text-lg font-bold flex items-center gap-2">
                                    <span class="material-icons-outlined text-primary">lightbulb</span>
                                    Trust Tips
                                </h3>
                                <p class="text-slate-500 dark:text-slate-400 text-sm font-medium mt-1">Why Choose Wyoming?</p>
                            </div>
                            <div class="flex flex-col gap-4">
                                <div class="flex items-start gap-3 p-3 rounded-lg bg-primary/5 border border-primary/10">
                                    <span class="material-icons-outlined text-primary text-xl">shield</span>
                                    <div>
                                        <p class="text-navy-900 dark:text-white text-sm font-bold">Asset Protection</p>
                                        <p class="text-xs text-slate-500 mt-1">Wyoming offers some of the strongest statutory protections for trust assets in the USA.</p>
                                    </div>
                                </div>
                                <div class="flex items-start gap-3 p-3 rounded-lg hover:bg-slate-50 dark:hover:bg-navy-700 transition-colors">
                                    <span class="material-icons-outlined text-slate-400 text-xl">lock</span>
                                    <div>
                                        <p class="text-navy-900 dark:text-white text-sm font-bold">Privacy Protection</p>
                                        <p class="text-xs text-slate-500 mt-1">Beneficiary and grantor names are not public record in Wyoming filings.</p>
                                    </div>
                                </div>
                                <div class="flex items-start gap-3 p-3 rounded-lg hover:bg-slate-50 dark:hover:bg-navy-700 transition-colors">
                                    <span class="material-icons-outlined text-slate-400 text-xl">payments</span>
                                    <div>
                                        <p class="text-navy-900 dark:text-white text-sm font-bold">Tax Advantages</p>
                                        <p class="text-xs text-slate-500 mt-1">0% state income tax for non-resident trust creators.</p>
                                    </div>
                                </div>
                                <div class="flex items-start gap-3 p-3 rounded-lg hover:bg-slate-50 dark:hover:bg-navy-700 transition-colors">
                                    <span class="material-icons-outlined text-slate-400 text-xl">currency_bitcoin</span>
                                    <div>
                                        <p class="text-navy-900 dark:text-white text-sm font-bold">Crypto-Friendly</p>
                                        <p class="text-xs text-slate-500 mt-1">Explicit laws recognizing digital assets as legal property within trusts.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </aside>
            </div>
            <div class="mt-8 flex justify-between">
                <button onclick="previousStep()" class="px-6 py-2 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white">Previous</button>
            </div>
        </div>
    `;
}

function renderBeneficiariesStep() {
    const totalAllocation = onboardingData.beneficiaries.reduce((sum, ben) => sum + (parseFloat(ben.allocation) || 0), 0);
    const isValid = Math.abs(totalAllocation - 100) < 0.01;
    const hasMyself = onboardingData.beneficiaries.some(b => b.is_myself);
    
    return `
        <div class="max-w-3xl mx-auto">
            <div class="mb-8">
                <h1 class="text-navy-900 dark:text-white text-4xl font-black leading-tight tracking-tight mb-3">Add Beneficiaries</h1>
                <p class="text-slate-500 dark:text-slate-400 text-lg font-normal leading-relaxed">Who should receive assets from this trust?</p>
            </div>
            
            <div class="bg-white dark:bg-navy-800 border border-slate-200 dark:border-slate-700 rounded-xl p-8 shadow-sm mb-6">
                <div class="flex items-center gap-3 mb-6">
                    <input type="checkbox" id="addMyselfCheckbox" ${hasMyself ? 'checked' : ''} class="w-5 h-5 text-primary border-slate-300 rounded focus:ring-primary cursor-pointer"/>
                    <label for="addMyselfCheckbox" class="text-navy-900 dark:text-white font-semibold text-lg cursor-pointer">Add Myself as Beneficiary</label>
                </div>
                <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">Include yourself in the beneficiary list</p>
            </div>
            
            <div id="beneficiariesList" class="space-y-4 mb-6">
                ${onboardingData.beneficiaries.length === 0 ? `
                    <div class="bg-slate-50 dark:bg-slate-800/50 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-8 text-center">
                        <p class="text-slate-600 dark:text-slate-400 mb-4">No beneficiaries added yet.</p>
                        <p class="text-sm text-slate-500 dark:text-slate-500">Check "Add Myself as Beneficiary" above or click "Add Another Beneficiary" below to get started.</p>
                    </div>
                ` : ''}
                ${onboardingData.beneficiaries.map((ben, idx) => `
                    <div class="bg-white dark:bg-navy-800 border border-slate-200 dark:border-slate-700 rounded-xl p-6 shadow-sm">
                        <div class="flex justify-between items-start mb-4">
                            <h3 class="text-lg font-bold text-navy-900 dark:text-white">Beneficiary #${idx + 1}${ben.is_myself ? ' <span class="text-sm text-primary">(Myself)</span>' : ''}</h3>
                            ${ben.is_myself ? '' : `<button onclick="removeBeneficiary(${idx})" class="text-red-600 hover:text-red-700 font-medium">Remove</button>`}
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-semibold text-navy-900 dark:text-slate-200 mb-2">Primary Full Name *</label>
                                <input type="text" value="${escapeHtml(ben.name || '')}" onchange="updateBeneficiary(${idx}, 'name', this.value)" ${ben.is_myself ? 'readonly' : ''} placeholder="${ben.is_myself ? 'Your name' : 'Jane Doe'}" autocomplete="off" class="w-full px-4 py-2 border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-navy-900 text-navy-900 dark:text-white focus:ring-2 focus:ring-primary ${ben.is_myself ? 'bg-slate-100 dark:bg-slate-700 cursor-not-allowed' : ''}" required/>
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-navy-900 dark:text-slate-200 mb-2">Relationship *</label>
                                <select onchange="updateBeneficiary(${idx}, 'relationship', this.value)" ${ben.is_myself ? 'disabled' : ''} class="w-full px-4 py-2 border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-navy-900 text-navy-900 dark:text-white focus:ring-2 focus:ring-primary ${ben.is_myself ? 'bg-slate-100 dark:bg-slate-700 cursor-not-allowed' : ''}" required>
                                    <option value="">Select</option>
                                    <option value="Self" ${ben.relationship === 'Self' ? 'selected' : ''}>Self</option>
                                    <option value="Spouse" ${ben.relationship === 'Spouse' ? 'selected' : ''}>Spouse</option>
                                    <option value="Child" ${ben.relationship === 'Child' ? 'selected' : ''}>Child</option>
                                    <option value="Parent" ${ben.relationship === 'Parent' ? 'selected' : ''}>Parent</option>
                                    <option value="Sibling" ${ben.relationship === 'Sibling' ? 'selected' : ''}>Sibling</option>
                                    <option value="Other" ${ben.relationship === 'Other' ? 'selected' : ''}>Other</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-navy-900 dark:text-slate-200 mb-2">Email</label>
                                <input type="email" value="${escapeHtml(ben.email || '')}" onchange="updateBeneficiary(${idx}, 'email', this.value)" ${ben.is_myself ? 'readonly' : ''} placeholder="${ben.is_myself ? 'Your email' : 'jane@example.com'}" autocomplete="off" class="w-full px-4 py-2 border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-navy-900 text-navy-900 dark:text-white focus:ring-2 focus:ring-primary ${ben.is_myself ? 'bg-slate-100 dark:bg-slate-700 cursor-not-allowed' : ''}"/>
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-navy-900 dark:text-slate-200 mb-2">Allocation % *</label>
                                <input type="number" id="allocation_${idx}" data-index="${idx}" min="0" max="100" step="0.01" value="${ben.allocation || ''}" onchange="updateBeneficiary(${idx}, 'allocation', this.value)" oninput="updateBeneficiary(${idx}, 'allocation', this.value)" placeholder="50" class="w-full px-4 py-2 border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-navy-900 text-navy-900 dark:text-white focus:ring-2 focus:ring-primary" required/>
                            </div>
                            <div class="md:col-span-2">
                                <label class="block text-sm font-semibold text-navy-900 dark:text-slate-200 mb-2">Crypto Wallet Address (Optional)</label>
                                <input type="text" value="${escapeHtml(ben.wallet_address || '')}" onchange="updateBeneficiary(${idx}, 'wallet_address', this.value)" placeholder="0x..." class="w-full px-4 py-2 border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-navy-900 text-navy-900 dark:text-white focus:ring-2 focus:ring-primary"/>
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
            
            <button onclick="addNewBeneficiary()" class="w-full py-3 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-lg text-slate-600 dark:text-slate-400 hover:border-primary hover:text-primary transition-colors mb-6">
                + Add Another Beneficiary
            </button>
            
            <div class="bg-blue-50 dark:bg-blue-900/20 rounded-xl p-4 border border-blue-100 dark:border-blue-800/50 mb-6">
                <p class="text-sm text-blue-800 dark:text-blue-100">
                    <span class="font-bold">Note:</span> Total allocation must equal 100%. 
                    <span id="allocationStatus" class="font-semibold ${isValid ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}">
                        Current total: ${totalAllocation.toFixed(2)}%
                    </span>
                </p>
            </div>
            
            <div class="mt-8 flex justify-between">
                <button onclick="previousStep()" class="px-6 py-2 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white">Previous</button>
                <button onclick="validateAndNext()" ${isValid ? '' : 'disabled'} class="px-6 py-2 bg-primary text-white rounded-lg font-semibold hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed">
                    Next: Review & Payment
                </button>
            </div>
        </div>
    `;
}


function renderReviewStep() {
    const selectedService = getSelectedTrustService();
    const price = selectedService ? (selectedService.is_free ? 0.00 : parseFloat(selectedService.price || 0)) : 0.00;
    const isFree = !selectedService || !!selectedService.is_free || price <= 0;
    const paymentStage = onboardingData.payment_stage || 'select';
    const pi = onboardingData.personal_info || {};
    const serviceName = selectedService ? selectedService.service_name : 'Not selected';
    const serviceKey = selectedService ? selectedService.service_key : '';
    const trustTypeName = serviceKey === 'revocable_living_trust' ? 'Revocable Living Trust' : 
                         serviceKey === 'irrevocable_trust' ? 'Irrevocable Trust' : 'Not selected';
    
    // Load payment methods only when needed (paid services)
    if (currentStep === 4 && !isFree) {
        setTimeout(() => loadPaymentMethods(), 100);
    }

    return `
        <div class="w-full">
            <div class="flex flex-col gap-2 mb-6">
                <h1 class="text-slate-900 dark:text-white text-4xl font-black leading-tight tracking-tight">Final Step: Review & Secure Your Trust</h1>
                <p class="text-slate-600 dark:text-slate-400 text-lg font-normal leading-normal">Confirm your details and choose a payment method to finalize your trust.</p>
            </div>
            <div class="grid grid-cols-1 lg:grid-cols-5 gap-8 items-start">
                <div class="lg:col-span-3 flex flex-col gap-6">
                    <div class="flex flex-col gap-4">
                        <h2 class="text-slate-900 dark:text-white text-xl font-bold flex items-center gap-2">
                            <span class="material-icons-outlined text-primary">verified_user</span>
                            Review Your Information
                        </h2>
                        <details class="group rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm" open>
                            <summary class="flex cursor-pointer items-center justify-between p-5 list-none">
                                <div class="flex items-center gap-3">
                                    <div class="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                                        <span class="material-icons-outlined text-xl">person</span>
                                    </div>
                                    <p class="text-slate-900 dark:text-white font-semibold">Personal Information</p>
                                </div>
                                <div class="flex items-center gap-4">
                                    <button type="button" onclick="window.location.href='?step=2'" class="text-primary text-sm font-bold hover:underline">Edit</button>
                                    <span class="material-icons-outlined text-slate-400 group-open:rotate-180 transition-transform">expand_more</span>
                                </div>
                            </summary>
                            <div class="px-5 pb-5 pt-0 border-t border-slate-100 dark:border-slate-800 mt-2">
                                <div class="grid grid-cols-2 gap-4 pt-4">
                                    <div>
                                        <p class="text-slate-500 dark:text-slate-400 text-xs uppercase font-bold tracking-wider">Full Legal Name</p>
                                        <p class="text-slate-900 dark:text-slate-100 font-medium">${escapeHtml(pi.full_name || 'Not provided')}</p>
                                    </div>
                                    <div>
                                        <p class="text-slate-500 dark:text-slate-400 text-xs uppercase font-bold tracking-wider">Email Address</p>
                                        <p class="text-slate-900 dark:text-slate-100 font-medium">${escapeHtml(pi.email || 'Not provided')}</p>
                                    </div>
                                    <div class="col-span-2">
                                        <p class="text-slate-500 dark:text-slate-400 text-xs uppercase font-bold tracking-wider">Address</p>
                                        <p class="text-slate-900 dark:text-slate-100 font-medium">
                                            ${escapeHtml([pi.street, pi.city, pi.state, pi.zip].filter(Boolean).join(', ') || 'Not provided')}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </details>
                        <details class="group rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm" open>
                            <summary class="flex cursor-pointer items-center justify-between p-5 list-none">
                                <div class="flex items-center gap-3">
                                    <div class="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                                        <span class="material-icons-outlined text-xl">groups</span>
                                    </div>
                                    <p class="text-slate-900 dark:text-white font-semibold">Beneficiaries</p>
                                </div>
                                <div class="flex items-center gap-4">
                                    <button type="button" onclick="window.location.href='?step=3'" class="text-primary text-sm font-bold hover:underline">Edit</button>
                                    <span class="material-icons-outlined text-slate-400 group-open:rotate-180 transition-transform">expand_more</span>
                                </div>
                            </summary>
                            <div class="px-5 pb-5 pt-0 border-t border-slate-100 dark:border-slate-800 mt-2">
                                <div class="pt-4 space-y-4">
                                    ${onboardingData.beneficiaries.length > 0 ? 
                                        onboardingData.beneficiaries.map(ben => `
                                            <div class="flex justify-between items-center bg-slate-50 dark:bg-slate-800/50 p-3 rounded-lg">
                                                <div>
                                                    <p class="font-medium text-slate-900 dark:text-white">${escapeHtml(ben.name)}${ben.is_myself ? ' <span class="text-sm text-primary">(Myself)</span>' : ''}</p>
                                                    <p class="text-sm text-slate-500 dark:text-slate-400">${escapeHtml(ben.relationship || '')} - ${ben.email || 'No email'}</p>
                                                </div>
                                                <span class="font-bold text-slate-900 dark:text-white">${ben.allocation}%</span>
                                            </div>
                                        `).join('') :
                                        '<p class="text-slate-500 dark:text-slate-400">No beneficiaries added</p>'
                                    }
                                </div>
                            </div>
                        </details>
                        <details class="group rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm" open>
                            <summary class="flex cursor-pointer items-center justify-between p-5 list-none">
                                <div class="flex items-center gap-3">
                                    <div class="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                                        <span class="material-icons-outlined text-xl">account_balance</span>
                                    </div>
                                    <p class="text-slate-900 dark:text-white font-semibold">Trust Type</p>
                                </div>
                                <div class="flex items-center gap-4">
                                    <button type="button" onclick="window.location.href='?step=1'" class="text-primary text-sm font-bold hover:underline">Edit</button>
                                    <span class="material-icons-outlined text-slate-400 group-open:rotate-180 transition-transform">expand_more</span>
                                </div>
                            </summary>
                            <div class="px-5 pb-5 pt-0 border-t border-slate-100 dark:border-slate-800 mt-2">
                                <div class="pt-4 space-y-4">
                                    <div>
                                        <p class="text-slate-500 dark:text-slate-400 text-xs uppercase font-bold tracking-wider">Trust Type</p>
                                        <p class="text-slate-900 dark:text-slate-100 font-medium">${escapeHtml(trustTypeName)}</p>
                                    </div>
                                </div>
                            </div>
                        </details>
                    </div>
                    <div class="bg-blue-50 dark:bg-blue-900/20 rounded-xl p-6 border border-blue-100 dark:border-blue-800/50 flex flex-col md:flex-row items-center gap-6">
                        <div class="flex -space-x-2">
                            <div class="size-12 rounded-full border-2 border-white dark:border-slate-900 bg-white dark:bg-slate-800 flex items-center justify-center text-primary shadow-sm" title="SSL Encrypted">
                                <span class="material-icons-outlined">lock</span>
                            </div>
                            <div class="size-12 rounded-full border-2 border-white dark:border-slate-900 bg-white dark:bg-slate-800 flex items-center justify-center text-green-500 shadow-sm" title="Compliance Verified">
                                <span class="material-icons-outlined">security</span>
                            </div>
                            <div class="size-12 rounded-full border-2 border-white dark:border-slate-900 bg-white dark:bg-slate-800 flex items-center justify-center text-primary shadow-sm" title="Secure Payment">
                                <span class="material-icons-outlined">encrypted</span>
                            </div>
                        </div>
                        <div>
                            <p class="text-slate-900 dark:text-white font-bold text-lg">Your data is secured with bank-grade encryption</p>
                            <p class="text-slate-600 dark:text-slate-400 text-sm">We use 256-bit AES encryption and multi-signature security protocols to ensure your legal documents and assets are protected.</p>
                        </div>
                    </div>

                    <!-- Payment -->
                    <div class="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
                        <div class="p-6 border-b border-slate-100 dark:border-slate-800">
                            <h2 class="text-slate-900 dark:text-white text-xl font-bold flex items-center gap-2">
                                <span class="material-icons-outlined text-primary">payments</span>
                                ${isFree ? 'Free Checkout' : 'Payment'}
                            </h2>
                            <p class="text-slate-600 dark:text-slate-400 text-sm mt-1">
                                ${isFree ? 'This service is free. No payment method is required.' : 'Pick a payment method, review the details, then confirm.'}
                            </p>
                        </div>
                        <div class="p-6" id="paymentFlowContainer">
                            ${isFree ? `
                                <div class="rounded-xl border border-green-200 dark:border-green-900 bg-green-50 dark:bg-green-900/20 p-5">
                                    <p class="font-bold text-slate-900 dark:text-white">No payment required</p>
                                    <p class="text-sm text-slate-600 dark:text-slate-400 mt-1">Click <strong>Complete Free Checkout</strong> to create your trust and go to your dashboard.</p>
                                </div>
                            ` : (
                                paymentStage === 'details'
                                    ? renderSelectedPaymentDetails(price)
                                    : paymentStage === 'confirmed'
                                        ? renderPaymentConfirmed()
                                        : '<div class="text-center py-4 text-slate-500 text-sm">Loading payment methods...</div>'
                            )}
                        </div>
                    </div>
                </div>
                <aside class="flex flex-col gap-6 lg:col-span-2 sticky top-24">
                    <div class="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-lg overflow-hidden">
                        <div class="p-6 border-b border-slate-100 dark:border-slate-800">
                            <h2 class="text-slate-900 dark:text-white text-xl font-bold">Order Summary</h2>
                        </div>
                        <div class="p-6 space-y-4">
                            <div class="flex justify-between text-sm">
                                <span class="text-slate-600 dark:text-slate-400">Trust Formation Fee</span>
                                <span class="text-slate-900 dark:text-white font-medium">$${price.toFixed(2)}</span>
                            </div>
                            <div class="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center">
                                <span class="text-slate-900 dark:text-white font-black text-lg">Total Amount</span>
                                <span class="text-primary font-black text-2xl tracking-tighter">$${price.toFixed(2)}</span>
                            </div>
                        </div>
                        <div class="px-6 pb-6">
                            ${isFree ? `
                                <button onclick="completeFreeCheckout()" class="w-full bg-primary hover:opacity-90 text-white font-bold py-4 px-6 rounded-xl transition-all shadow-lg flex items-center justify-center gap-3">
                                    <span class="material-icons-outlined">check_circle</span>
                                    Complete Free Checkout
                                </button>
                            ` : (
                                paymentStage === 'details'
                                    ? `
                                        <button onclick="confirmPaymentAndCreateTrust()" class="w-full bg-primary hover:opacity-90 text-white font-bold py-4 px-6 rounded-xl transition-all shadow-lg flex items-center justify-center gap-3">
                                            <span class="material-icons-outlined">verified</span>
                                            I’ve made this payment
                                        </button>
                                        <button onclick="backToPaymentSelection()" class="w-full mt-3 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-900 dark:text-white font-semibold py-3 px-6 rounded-xl">
                                            Change payment method
                                        </button>
                                    `
                                    : paymentStage === 'confirmed'
                                        ? `
                                            <button onclick="doneToDashboard()" class="w-full bg-primary hover:opacity-90 text-white font-bold py-4 px-6 rounded-xl transition-all shadow-lg flex items-center justify-center gap-3">
                                                <span class="material-icons-outlined">dashboard</span>
                                                Done — Go to Dashboard
                                            </button>
                                        `
                                        : `
                                            <p class="text-slate-500 dark:text-slate-400 text-xs uppercase font-bold tracking-wider mb-3">Select Payment Method</p>
                                            <div id="paymentMethodsContainer" class="space-y-3 mb-6">
                                                <div class="text-center py-4 text-slate-500 text-sm">Loading payment methods...</div>
                                            </div>
                                            <button onclick="goToPaymentDetails()" ${onboardingData.payment_method_id ? '' : 'disabled'} class="w-full bg-primary hover:opacity-90 text-white font-bold py-4 px-6 rounded-xl transition-all shadow-lg flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed">
                                                <span class="material-icons-outlined">arrow_forward</span>
                                                Continue to Payment Details
                                            </button>
                                        `
                            )}
                            <p class="text-center text-slate-400 text-[10px] mt-4 uppercase tracking-widest font-bold">
                                Guaranteed Secure Transaction
                            </p>
                        </div>
                    </div>
                </aside>
            </div>
            <div class="mt-8 flex justify-start">
                <button onclick="previousStep()" class="px-6 py-2 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white">Previous</button>
            </div>
        </div>
    `;
}

function selectTrustType(serviceKey, serviceId) {
    onboardingData.trust_service_id = serviceId;
    onboardingData.trust_type = serviceKey === 'revocable_living_trust' ? 'revocable' : 
                                serviceKey === 'irrevocable_trust' ? 'irrevocable' : '';
    
    // Enable next button without re-rendering the entire step
    const nextBtn = document.getElementById('nextBtn');
    if (nextBtn) {
        nextBtn.disabled = false;
        // Update visual selection by re-rendering the step content only
        loadStep(1);
    }
}

function savePersonalInfo() {
    onboardingData.personal_info = {
        full_name: document.getElementById('fullNameInput').value.trim(),
        email: document.getElementById('emailInput').value.trim(),
        street: document.getElementById('streetInput').value.trim(),
        city: document.getElementById('cityInput').value.trim(),
        state: document.getElementById('stateInput').value.trim(),
        zip: document.getElementById('zipInput').value.trim()
    };
    
    // Save password if not logged in
    if (!isLoggedIn) {
        const passwordInput = document.getElementById('passwordInput');
        const confirmPasswordInput = document.getElementById('confirmPasswordInput');
        if (passwordInput) onboardingData.password = passwordInput.value;
        if (confirmPasswordInput) onboardingData.confirm_password = confirmPasswordInput.value;
    }
    saveOnboardingToStorage();
}

async function savePersonalInfoAndContinue() {
    savePersonalInfo();
    saveOnboardingToStorage();
    
    // If not logged in, register the user first
    if (!isLoggedIn) {
        if (!onboardingData.password || !onboardingData.confirm_password) {
            alert('Please enter and confirm your password.');
            return;
        }
        
        if (onboardingData.password !== onboardingData.confirm_password) {
            alert('Passwords do not match.');
            return;
        }
        
        if (onboardingData.password.length < 8) {
            alert('Password must be at least 8 characters long.');
            return;
        }
        
        // Register the user
        try {
            const response = await fetch('../api/register.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    full_name: onboardingData.personal_info.full_name,
                    email: onboardingData.personal_info.email,
                    password: onboardingData.password
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                // Store registration data
                onboardingData.registration_email = data.email;
                onboardingData.requires_verification = data.requires_verification;
                onboardingData.email_sent = data.email_sent;
                saveOnboardingToStorage();
                
                // If email verification is required, show OTP step
                if (data.requires_verification) {
                    // Show OTP verification step instead of going to step 3
                    showOTPVerificationStep();
                } else {
                    // No verification needed, continue to step 3
                    saveOnboardingToStorage();
                    window.location.href = 'onboarding.php?step=3';
                }
            } else {
                alert('Registration failed: ' + (data.message || 'Unknown error'));
            }
        } catch (error) {
            console.error('Registration error:', error);
            alert('An error occurred during registration. Please try again.');
        }
    } else {
        // Already logged in, just continue
        nextStep();
    }
}

function showOTPVerificationStep() {
    const content = document.getElementById('onboardingContent');
    content.innerHTML = renderOTPVerificationStep();
    // Update progress to show this is still step 2 (before beneficiaries)
    document.getElementById('currentStep').textContent = '2';
    document.getElementById('stepTitle').textContent = 'Verify Email';
    document.getElementById('progressBar').style.width = '50%';
    // Attach OTP input event listeners after HTML is inserted
    setupOTPInputs();
    saveOnboardingToStorage();
}

function renderOTPVerificationStep() {
    const email = onboardingData.registration_email || onboardingData.personal_info?.email || '';
    return `
        <div class="max-w-md mx-auto">
            <div class="mb-8 text-center">
                <div class="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
                    <span class="material-icons-outlined text-primary text-3xl">mail_outline</span>
                </div>
                <h1 class="text-navy-900 dark:text-white text-3xl font-black leading-tight tracking-tight mb-3">Verify Your Email</h1>
                <p class="text-slate-500 dark:text-slate-400 text-base leading-relaxed">
                    We've sent a 6-digit verification code to<br>
                    <strong class="text-navy-900 dark:text-white">${escapeHtml(email)}</strong>
                </p>
            </div>
            
            <div class="bg-white dark:bg-navy-800 border border-slate-200 dark:border-slate-700 rounded-xl p-8 shadow-sm mb-6">
                <form onsubmit="event.preventDefault(); verifyOTP();" class="space-y-6">
                    <div>
                        <label class="block text-sm font-semibold text-navy-900 dark:text-slate-200 mb-3 text-center">
                            Enter Verification Code
                        </label>
                        <div class="flex justify-center gap-2 mb-4">
                            <input type="text" id="otp1" maxlength="1" pattern="[0-9]" inputmode="numeric" 
                                   class="w-12 h-14 text-center text-2xl font-bold border-2 border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-navy-900 text-navy-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary" 
                                   autocomplete="off" required/>
                            <input type="text" id="otp2" maxlength="1" pattern="[0-9]" inputmode="numeric" 
                                   class="w-12 h-14 text-center text-2xl font-bold border-2 border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-navy-900 text-navy-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary" 
                                   autocomplete="off" required/>
                            <input type="text" id="otp3" maxlength="1" pattern="[0-9]" inputmode="numeric" 
                                   class="w-12 h-14 text-center text-2xl font-bold border-2 border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-navy-900 text-navy-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary" 
                                   autocomplete="off" required/>
                            <span class="w-2"></span>
                            <input type="text" id="otp4" maxlength="1" pattern="[0-9]" inputmode="numeric" 
                                   class="w-12 h-14 text-center text-2xl font-bold border-2 border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-navy-900 text-navy-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary" 
                                   autocomplete="off" required/>
                            <input type="text" id="otp5" maxlength="1" pattern="[0-9]" inputmode="numeric" 
                                   class="w-12 h-14 text-center text-2xl font-bold border-2 border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-navy-900 text-navy-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary" 
                                   autocomplete="off" required/>
                            <input type="text" id="otp6" maxlength="1" pattern="[0-9]" inputmode="numeric" 
                                   class="w-12 h-14 text-center text-2xl font-bold border-2 border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-navy-900 text-navy-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary" 
                                   autocomplete="off" required/>
                        </div>
                        
                        <div id="otpError" class="hidden mb-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg text-red-700 dark:text-red-400 text-sm text-center"></div>
                        
                        <button type="submit" id="verifyOTPBtn" class="w-full bg-primary hover:opacity-90 text-white font-semibold py-3 px-6 rounded-lg transition-opacity">
                            Verify & Continue
                        </button>
                    </div>
                </form>
                
                <div class="mt-6 pt-6 border-t border-slate-200 dark:border-slate-700">
                    <p class="text-center text-sm text-slate-500 dark:text-slate-400 mb-4">
                        Didn't receive the code?
                    </p>
                    <button onclick="resendOTP()" id="resendOTPBtn" class="w-full text-primary hover:text-primary/80 font-semibold py-2 px-4 rounded-lg transition-colors">
                        Resend Code
                    </button>
                    <p id="resendCooldown" class="hidden text-center text-xs text-slate-400 dark:text-slate-500 mt-2"></p>
                </div>
            </div>
            
            <div class="text-center">
                <button onclick="goBackToPersonalInfo()" class="text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white text-sm">
                    ← Back to Personal Info
                </button>
            </div>
        </div>
    `;
}

function setupOTPInputs() {
    // Auto-focus and move to next input
    const otpInputs = ['otp1', 'otp2', 'otp3', 'otp4', 'otp5', 'otp6'];
    otpInputs.forEach((inputId, index) => {
        const input = document.getElementById(inputId);
        if (!input) return;
        
        input.addEventListener('input', (e) => {
            // Only allow numbers
            e.target.value = e.target.value.replace(/[^0-9]/g, '');
            if (e.target.value && index < otpInputs.length - 1) {
                const nextInput = document.getElementById(otpInputs[index + 1]);
                if (nextInput) nextInput.focus();
            }
        });
        
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Backspace' && !e.target.value && index > 0) {
                const prevInput = document.getElementById(otpInputs[index - 1]);
                if (prevInput) {
                    prevInput.focus();
                    prevInput.value = '';
                }
            }
        });
        
        // Prevent paste on individual inputs - allow paste only on first input
        if (index === 0) {
            input.addEventListener('paste', (e) => {
                e.preventDefault();
                const pastedData = (e.clipboardData || window.clipboardData).getData('text');
                const digits = pastedData.replace(/[^0-9]/g, '').slice(0, 6);
                if (digits.length === 6) {
                    otpInputs.forEach((id, idx) => {
                        const inp = document.getElementById(id);
                        if (inp) inp.value = digits[idx] || '';
                    });
                    document.getElementById('otp6').focus();
                }
            });
        }
    });
    
    // Focus first input on load
    setTimeout(() => {
        const firstInput = document.getElementById('otp1');
        if (firstInput) firstInput.focus();
    }, 100);
}

async function verifyOTP() {
    const otp1 = document.getElementById('otp1').value;
    const otp2 = document.getElementById('otp2').value;
    const otp3 = document.getElementById('otp3').value;
    const otp4 = document.getElementById('otp4').value;
    const otp5 = document.getElementById('otp5').value;
    const otp6 = document.getElementById('otp6').value;
    
    const otpCode = otp1 + otp2 + otp3 + otp4 + otp5 + otp6;
    
    if (otpCode.length !== 6) {
        showOTPError('Please enter all 6 digits');
        return;
    }
    
    const email = onboardingData.registration_email || onboardingData.personal_info?.email || '';
    if (!email) {
        showOTPError('Email not found. Please go back and re-enter your information.');
        return;
    }
    
    const verifyBtn = document.getElementById('verifyOTPBtn');
    const errorDiv = document.getElementById('otpError');
    
    verifyBtn.disabled = true;
    verifyBtn.textContent = 'Verifying...';
    errorDiv.classList.add('hidden');
    
    try {
        const response = await fetch('../api/verify-otp.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                otp: otpCode,
                email: email
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Email verified successfully - continue to step 3 (beneficiaries)
            showToast('Email verified successfully!', 'success');
            setTimeout(() => {
                saveOnboardingToStorage();
                window.location.href = 'onboarding.php?step=3';
            }, 500);
        } else {
            showOTPError(data.message || 'Invalid verification code. Please try again.');
            verifyBtn.disabled = false;
            verifyBtn.textContent = 'Verify & Continue';
            // Clear OTP inputs
            document.querySelectorAll('#otp1, #otp2, #otp3, #otp4, #otp5, #otp6').forEach(input => input.value = '');
            document.getElementById('otp1').focus();
        }
    } catch (error) {
        console.error('OTP verification error:', error);
        showOTPError('An error occurred. Please try again.');
        verifyBtn.disabled = false;
        verifyBtn.textContent = 'Verify & Continue';
    }
}

function showOTPError(message) {
    const errorDiv = document.getElementById('otpError');
    if (errorDiv) {
        errorDiv.textContent = message;
        errorDiv.classList.remove('hidden');
    }
}

async function resendOTP() {
    const email = onboardingData.registration_email || onboardingData.personal_info?.email || '';
    if (!email) {
        showToast('Email not found', 'error');
        return;
    }
    
    const resendBtn = document.getElementById('resendOTPBtn');
    const cooldownDiv = document.getElementById('resendCooldown');
    
    resendBtn.disabled = true;
    resendBtn.textContent = 'Sending...';
    
    try {
        const response = await fetch('../api/user/resend-verification.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ email: email })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showToast('Verification code sent! Please check your email.', 'success');
            // Start cooldown countdown
            if (data.cooldown_remaining) {
                startResendCooldown(data.cooldown_remaining);
            }
        } else {
            showToast(data.message || 'Failed to resend code. Please try again.', 'error');
            if (data.cooldown_remaining && data.cooldown_remaining > 0) {
                startResendCooldown(data.cooldown_remaining);
            } else {
                resendBtn.disabled = false;
                resendBtn.textContent = 'Resend Code';
            }
        }
    } catch (error) {
        console.error('Resend OTP error:', error);
        showToast('An error occurred. Please try again.', 'error');
        resendBtn.disabled = false;
        resendBtn.textContent = 'Resend Code';
    }
}

function startResendCooldown(seconds) {
    const resendBtn = document.getElementById('resendOTPBtn');
    const cooldownDiv = document.getElementById('resendCooldown');
    
    let remaining = seconds;
    resendBtn.disabled = true;
    cooldownDiv.classList.remove('hidden');
    cooldownDiv.textContent = `Please wait ${remaining} seconds before requesting another code`;
    
    const interval = setInterval(() => {
        remaining--;
        if (remaining > 0) {
            cooldownDiv.textContent = `Please wait ${remaining} seconds before requesting another code`;
        } else {
            clearInterval(interval);
            resendBtn.disabled = false;
            resendBtn.textContent = 'Resend Code';
            cooldownDiv.classList.add('hidden');
        }
    }, 1000);
}

function goBackToPersonalInfo() {
    saveOnboardingToStorage();
    window.location.href = 'onboarding.php?step=2';
}

function addNewBeneficiary() {
    onboardingData.beneficiaries.push({
        name: '',
        relationship: '',
        email: '',
        allocation: 0,
        wallet_address: '',
        is_myself: false
    });
    saveOnboardingToStorage();
    loadStep(3);
}

function updateBeneficiary(index, field, value) {
    if (onboardingData.beneficiaries[index]) {
        // Don't allow editing name, email, or relationship for "myself"
        if (onboardingData.beneficiaries[index].is_myself && (field === 'name' || field === 'email' || field === 'relationship')) {
            return;
        }
        
        onboardingData.beneficiaries[index][field] = value;
        if (field === 'allocation') {
            onboardingData.beneficiaries[index].allocation = parseFloat(value) || 0;
            // Update the total allocation display without full reload
            updateAllocationDisplay();
        }
        saveOnboardingToStorage();
    }
}

function updateAllocationDisplay() {
    const totalAllocation = onboardingData.beneficiaries.reduce((sum, ben) => sum + (parseFloat(ben.allocation) || 0), 0);
    const isValid = Math.abs(totalAllocation - 100) < 0.01;
    const statusEl = document.getElementById('allocationStatus');
    const nextBtn = document.querySelector('button[onclick="validateAndNext()"]');
    
    if (statusEl) {
        statusEl.textContent = `Current total: ${totalAllocation.toFixed(2)}%`;
        statusEl.className = `font-semibold ${isValid ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`;
    }
    
    if (nextBtn) {
        if (isValid) {
            nextBtn.disabled = false;
            nextBtn.classList.remove('opacity-50', 'cursor-not-allowed');
        } else {
            nextBtn.disabled = true;
            nextBtn.classList.add('opacity-50', 'cursor-not-allowed');
        }
    }
}

function removeBeneficiary(index) {
    // Don't allow removing "myself" via this function
    if (onboardingData.beneficiaries[index] && onboardingData.beneficiaries[index].is_myself) {
        return;
    }
    onboardingData.beneficiaries.splice(index, 1);
    saveOnboardingToStorage();
    loadStep(3);
}

function toggleAddMyself(checked) {
    if (checked) {
        // Check if already added
        const exists = onboardingData.beneficiaries.find(b => b.is_myself);
        if (!exists && onboardingData.personal_info && onboardingData.personal_info.full_name) {
            onboardingData.beneficiaries.unshift({
                name: onboardingData.personal_info.full_name,
                relationship: 'Self',
                email: onboardingData.personal_info.email || '',
                allocation: 0,
                wallet_address: '',
                is_myself: true
            });
        }
    } else {
        // Remove myself
        const index = onboardingData.beneficiaries.findIndex(b => b.is_myself);
        if (index >= 0) {
            onboardingData.beneficiaries.splice(index, 1);
        }
    }
    saveOnboardingToStorage();
    loadStep(3);
}

function setupBeneficiariesStep() {
    // Attach checkbox event listener
    const checkbox = document.getElementById('addMyselfCheckbox');
    if (checkbox) {
        // Remove existing listeners by cloning
        const newCheckbox = checkbox.cloneNode(true);
        checkbox.parentNode.replaceChild(newCheckbox, checkbox);
        
        // Add fresh event listener
        document.getElementById('addMyselfCheckbox').addEventListener('change', function(e) {
            toggleAddMyself(e.target.checked);
        });
    }
    
    // Update allocation display on load
    updateAllocationDisplay();
}

function ensureDefaultBeneficiary() {
    if (!Array.isArray(onboardingData.beneficiaries)) onboardingData.beneficiaries = [];
    const hasNonMyself = onboardingData.beneficiaries.some(b => !b.is_myself);
    if (!hasNonMyself) {
        onboardingData.beneficiaries.push({
            name: '',
            relationship: '',
            email: '',
            allocation: 0,
            wallet_address: '',
            is_myself: false
        });
        saveOnboardingToStorage();
    }
}

function validateAndNext() {
    const totalAllocation = onboardingData.beneficiaries.reduce((sum, ben) => sum + (parseFloat(ben.allocation) || 0), 0);
    if (Math.abs(totalAllocation - 100) > 0.01) {
        alert('Total allocation must equal 100%. Current total: ' + totalAllocation.toFixed(2) + '%');
        return;
    }
    // Validate required fields
    for (let i = 0; i < onboardingData.beneficiaries.length; i++) {
        const ben = onboardingData.beneficiaries[i];
        if (!ben.name || !ben.relationship || !ben.allocation) {
            alert('Please fill in all required fields for Beneficiary #' + (i + 1));
            return;
        }
    }
    nextStep();
}

// Load payment methods when review step is loaded
let paymentMethods = [];

async function loadPaymentMethods() {
    try {
        const response = await fetch('../api/payment-methods.php');
        const data = await response.json();
        
        if (data.success && data.methods) {
            paymentMethods = data.methods;
            renderPaymentMethods(data.methods);
            // If we're on step 4 and in details stage, refresh the details panel now that methods exist
            if (currentStep === 4 && onboardingData.payment_stage === 'details') {
                loadStep(4);
            }
        } else {
            const container = document.getElementById('paymentMethodsContainer') || document.getElementById('paymentFlowContainer');
            if (container) {
                container.innerHTML = '<div class="text-center py-4 text-red-500 text-sm">Failed to load payment methods</div>';
            }
        }
    } catch (error) {
        console.error('Error loading payment methods:', error);
        const container = document.getElementById('paymentMethodsContainer') || document.getElementById('paymentFlowContainer');
        if (container) {
            container.innerHTML = '<div class="text-center py-4 text-red-500 text-sm">Error loading payment methods</div>';
        }
    }
}

function renderPaymentMethods(methods) {
    const container = document.getElementById('paymentMethodsContainer');
    if (!container) {
        // If we are not on the select stage, this container won't exist; no-op safely.
        return;
    }
    if (!methods || methods.length === 0) {
        container.innerHTML = '<div class="text-center py-4 text-slate-500 text-sm">No payment methods available</div>';
        return;
    }

    const selectedId = onboardingData.payment_method_id;
    const iconFor = (type) => {
        if (type === 'crypto') return 'currency_bitcoin';
        if (type === 'bank_transfer') return 'account_balance';
        if (type === 'paypal') return 'payments';
        return 'credit_card';
    };

    container.innerHTML = `
        <div class="grid grid-cols-1 gap-3">
            ${methods.map(m => `
                <button type="button"
                    onclick="selectPaymentMethod(${m.id}, '${m.method_type}')"
                    class="payment-method-card w-full rounded-xl border p-4 text-left transition-all hover:shadow-sm ${
                        (selectedId == m.id)
                            ? 'border-primary ring-2 ring-primary/30 bg-primary/5'
                            : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950'
                    }">
                    <div class="flex items-center justify-between gap-3">
                        <div class="flex items-center gap-3 min-w-0">
                            <div class="w-10 h-10 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
                                <span class="material-icons-outlined text-primary">${iconFor(m.method_type)}</span>
                            </div>
                            <div class="min-w-0">
                                <p class="font-bold text-slate-900 dark:text-white truncate">${escapeHtml(m.method_name || 'Payment Method')}</p>
                                <p class="text-xs text-slate-500 dark:text-slate-400">${escapeHtml((m.method_type || '').replace('_', ' '))}</p>
                            </div>
                        </div>
                        <div class="payment-method-radio">
                            <input type="radio" name="selected_payment_method" value="${m.id}" ${selectedId == m.id ? 'checked' : ''} />
                        </div>
                    </div>
                </button>
            `).join('')}
        </div>
    `;
}

function renderCryptoPaymentMethod(method, config) {
    const walletAddress = config.wallet_address || '';
    const qrCode = config.qr_code || '';
    const coinName = config.coin_name || method.method_name;
    const networkType = config.network_type || '';
    
    return `
        <div class="border border-slate-200 dark:border-slate-700 rounded-lg p-4 mb-3 payment-method-card" onclick="selectPaymentMethod(${method.id}, 'crypto')">
            <div class="flex items-start justify-between mb-3">
                <div class="flex-1">
                    <h4 class="font-bold text-slate-900 dark:text-white mb-1">${escapeHtml(coinName)}</h4>
                    ${networkType ? `<p class="text-xs text-slate-500 dark:text-slate-400">${escapeHtml(networkType)}</p>` : ''}
                </div>
                <div class="payment-method-radio">
                    <input type="radio" name="selected_payment_method" value="${method.id}" id="payment_${method.id}" 
                           ${onboardingData.payment_method_id == method.id ? 'checked' : ''}>
                    <label for="payment_${method.id}" class="cursor-pointer"></label>
                </div>
            </div>
            ${walletAddress ? `
                <div class="bg-slate-50 dark:bg-slate-800 rounded-lg p-3 mb-3">
                    <div class="flex items-center justify-between gap-2 mb-2">
                        <label class="text-xs font-semibold text-slate-600 dark:text-slate-400">Wallet Address</label>
                        <button onclick="event.stopPropagation(); copyToClipboard('${escapeHtml(walletAddress)}', ${method.id})" 
                                class="text-primary hover:text-primary/80 text-xs font-semibold flex items-center gap-1">
                            <span class="material-icons-outlined text-sm">content_copy</span>
                            Copy
                        </button>
                    </div>
                    <p class="text-xs font-mono text-slate-900 dark:text-white break-all" id="wallet_${method.id}">${escapeHtml(walletAddress)}</p>
                    <div id="copyFeedback_${method.id}" class="hidden text-xs text-green-600 dark:text-green-400 mt-1">✓ Copied!</div>
                </div>
            ` : ''}
            ${qrCode ? `
                <div class="flex justify-center mb-2">
                    <img src="../${qrCode}" alt="QR Code" class="max-w-32 max-h-32 border border-slate-200 dark:border-slate-700 rounded-lg p-2 bg-white">
                </div>
                <p class="text-xs text-center text-slate-500 dark:text-slate-400">Scan QR code to send payment</p>
            ` : ''}
        </div>
    `;
}

function renderBankPaymentMethod(method, config) {
    const bankName = config.bank_name || '';
    const accountName = config.account_name || '';
    const accountNumber = config.account_number_masked || config.account_number || '';
    const routingNumber = config.routing_number || '';
    const swiftCode = config.swift_code || '';
    const additionalDetails = config.additional_details || '';
    
    return `
        <div class="border border-slate-200 dark:border-slate-700 rounded-lg p-4 mb-3 payment-method-card" onclick="selectPaymentMethod(${method.id}, 'bank_transfer')">
            <div class="flex items-start justify-between mb-3">
                <div class="flex-1">
                    <h4 class="font-bold text-slate-900 dark:text-white mb-1">${escapeHtml(bankName)}</h4>
                    <p class="text-xs text-slate-500 dark:text-slate-400">${escapeHtml(accountName)}</p>
                </div>
                <div class="payment-method-radio">
                    <input type="radio" name="selected_payment_method" value="${method.id}" id="payment_${method.id}"
                           ${onboardingData.payment_method_id == method.id ? 'checked' : ''}>
                    <label for="payment_${method.id}" class="cursor-pointer"></label>
                </div>
            </div>
            <div class="space-y-2 text-xs">
                ${accountNumber ? `
                    <div class="flex items-center justify-between">
                        <span class="text-slate-600 dark:text-slate-400">Account Number:</span>
                        <span class="font-mono text-slate-900 dark:text-white">${escapeHtml(accountNumber)}</span>
                    </div>
                ` : ''}
                ${routingNumber ? `
                    <div class="flex items-center justify-between">
                        <span class="text-slate-600 dark:text-slate-400">Routing Number:</span>
                        <span class="font-mono text-slate-900 dark:text-white">${escapeHtml(routingNumber)}</span>
                    </div>
                ` : ''}
                ${swiftCode ? `
                    <div class="flex items-center justify-between">
                        <span class="text-slate-600 dark:text-slate-400">SWIFT/BIC:</span>
                        <span class="font-mono text-slate-900 dark:text-white">${escapeHtml(swiftCode)}</span>
                    </div>
                ` : ''}
                ${additionalDetails ? `
                    <div class="mt-2 pt-2 border-t border-slate-200 dark:border-slate-700">
                        <p class="text-slate-600 dark:text-slate-400 mb-1">Additional Details:</p>
                        <p class="text-slate-900 dark:text-white">${escapeHtml(additionalDetails)}</p>
                    </div>
                ` : ''}
            </div>
        </div>
    `;
}

function renderPayPalPaymentMethod(method, config) {
    const paypalEmail = config.paypal_email || config.paypal_tag || '';
    
    return `
        <div class="border border-slate-200 dark:border-slate-700 rounded-lg p-4 mb-3 payment-method-card" onclick="selectPaymentMethod(${method.id}, 'paypal')">
            <div class="flex items-start justify-between mb-3">
                <div class="flex-1">
                    <h4 class="font-bold text-slate-900 dark:text-white mb-1">PayPal</h4>
                    ${paypalEmail ? `<p class="text-xs text-slate-500 dark:text-slate-400">${escapeHtml(paypalEmail)}</p>` : ''}
                </div>
                <div class="payment-method-radio">
                    <input type="radio" name="selected_payment_method" value="${method.id}" id="payment_${method.id}"
                           ${onboardingData.payment_method_id == method.id ? 'checked' : ''}>
                    <label for="payment_${method.id}" class="cursor-pointer"></label>
                </div>
            </div>
            <p class="text-xs text-slate-600 dark:text-slate-400">You will be redirected to PayPal to complete the payment.</p>
        </div>
    `;
}

function selectPaymentMethod(methodId, methodType) {
    onboardingData.payment_method_id = methodId;
    onboardingData.payment_method = methodType;
    onboardingData.payment_stage = 'select';
    onboardingData.payment_confirmed = false;
    saveOnboardingToStorage();
    
    // Update radio button selection
    document.querySelectorAll('input[name="selected_payment_method"]').forEach(radio => {
        radio.checked = radio.value == methodId;
    });
    
    // Update visual selection
    document.querySelectorAll('.payment-method-card').forEach(card => {
        card.classList.remove('border-primary', 'ring-2', 'ring-primary');
        card.classList.add('border-slate-200', 'dark:border-slate-700');
    });
    
    const selectedCard = document.querySelector(`input[name="selected_payment_method"][value="${methodId}"]`)?.closest('.payment-method-card');
    if (selectedCard) {
        selectedCard.classList.remove('border-slate-200', 'dark:border-slate-700');
        selectedCard.classList.add('border-primary', 'ring-2', 'ring-primary');
    }
}

function goToPaymentDetails() {
    if (!onboardingData.payment_method_id) return;
    onboardingData.payment_stage = 'details';
    saveOnboardingToStorage();
    loadStep(4);
}

function backToPaymentSelection() {
    onboardingData.payment_stage = 'select';
    onboardingData.payment_confirmed = false;
    saveOnboardingToStorage();
    loadStep(4);
}

function getSelectedPaymentMethodObj() {
    if (!paymentMethods || !Array.isArray(paymentMethods)) return null;
    return paymentMethods.find(m => (m.id == onboardingData.payment_method_id)) || null;
}

function renderSelectedPaymentDetails(amount) {
    const method = getSelectedPaymentMethodObj();
    if (!method) {
        return `
            <div class="text-center py-4">
                <p class="text-sm text-slate-500">Select a payment method to continue.</p>
                <button onclick="backToPaymentSelection()" class="mt-3 text-primary font-semibold">Back</button>
            </div>
        `;
    }

    const config = method.config_data || {};

    let detailsHtml = '';
    if (method.method_type === 'crypto') {
        const walletAddress = config.wallet_address || '';
        const qrCode = config.qr_code || '';
        const coinName = config.coin_name || method.method_name;
        const networkType = config.network_type || '';
        detailsHtml = `
            <div class="rounded-xl border border-slate-200 dark:border-slate-800 p-4">
                <p class="font-bold text-slate-900 dark:text-white mb-2">Crypto payment details</p>
                <p class="text-sm text-slate-600 dark:text-slate-400">Send <strong class="text-slate-900 dark:text-white">$${amount.toFixed(2)}</strong> using ${escapeHtml(coinName)} ${networkType ? `(${escapeHtml(networkType)})` : ''}.</p>
                ${walletAddress ? `
                    <div class="mt-4 bg-slate-50 dark:bg-slate-800 rounded-lg p-3">
                        <div class="flex items-center justify-between gap-2 mb-2">
                            <p class="text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wide">Wallet Address</p>
                            <button onclick="copyToClipboard('${escapeHtml(walletAddress)}', ${method.id})" class="text-primary text-xs font-semibold flex items-center gap-1">
                                <span class="material-icons-outlined text-sm">content_copy</span> Copy
                            </button>
                        </div>
                        <p class="text-xs font-mono text-slate-900 dark:text-white break-all" id="wallet_${method.id}">${escapeHtml(walletAddress)}</p>
                        <div id="copyFeedback_${method.id}" class="hidden text-xs text-green-600 dark:text-green-400 mt-1">✓ Copied!</div>
                    </div>
                ` : ''}
                ${qrCode ? `
                    <div class="mt-4 flex flex-col sm:flex-row items-center gap-4">
                        <img src="../${qrCode}" alt="QR Code" class="max-w-40 max-h-40 border border-slate-200 dark:border-slate-700 rounded-lg p-2 bg-white">
                        <p class="text-xs text-slate-500 dark:text-slate-400">Scan to pay.</p>
                    </div>
                ` : ''}
            </div>
        `;
    } else if (method.method_type === 'bank_transfer') {
        const bankName = config.bank_name || '';
        const accountName = config.account_name || '';
        const accountNumber = config.account_number_masked || config.account_number || '';
        const routingNumber = config.routing_number || '';
        const swiftCode = config.swift_code || '';
        const additionalDetails = config.additional_details || '';
        detailsHtml = `
            <div class="rounded-xl border border-slate-200 dark:border-slate-800 p-4">
                <p class="font-bold text-slate-900 dark:text-white mb-2">Bank transfer details</p>
                <p class="text-sm text-slate-600 dark:text-slate-400 mb-3">Transfer <strong class="text-slate-900 dark:text-white">$${amount.toFixed(2)}</strong> using the details below.</p>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                    <div><p class="text-xs text-slate-500 dark:text-slate-400 uppercase font-bold tracking-wide">Bank</p><p class="text-slate-900 dark:text-white">${escapeHtml(bankName)}</p></div>
                    <div><p class="text-xs text-slate-500 dark:text-slate-400 uppercase font-bold tracking-wide">Account Name</p><p class="text-slate-900 dark:text-white">${escapeHtml(accountName)}</p></div>
                    ${accountNumber ? `<div><p class="text-xs text-slate-500 dark:text-slate-400 uppercase font-bold tracking-wide">Account #</p><p class="text-slate-900 dark:text-white font-mono">${escapeHtml(accountNumber)}</p></div>` : ''}
                    ${routingNumber ? `<div><p class="text-xs text-slate-500 dark:text-slate-400 uppercase font-bold tracking-wide">Routing</p><p class="text-slate-900 dark:text-white font-mono">${escapeHtml(routingNumber)}</p></div>` : ''}
                    ${swiftCode ? `<div><p class="text-xs text-slate-500 dark:text-slate-400 uppercase font-bold tracking-wide">SWIFT/BIC</p><p class="text-slate-900 dark:text-white font-mono">${escapeHtml(swiftCode)}</p></div>` : ''}
                </div>
                ${additionalDetails ? `<div class="mt-3 text-sm"><p class="text-xs text-slate-500 dark:text-slate-400 uppercase font-bold tracking-wide">Notes</p><p class="text-slate-900 dark:text-white whitespace-pre-wrap">${escapeHtml(additionalDetails)}</p></div>` : ''}
            </div>
        `;
    } else if (method.method_type === 'paypal') {
        const paypalEmail = config.paypal_email || config.paypal_tag || '';
        detailsHtml = `
            <div class="rounded-xl border border-slate-200 dark:border-slate-800 p-4">
                <p class="font-bold text-slate-900 dark:text-white mb-2">PayPal details</p>
                <p class="text-sm text-slate-600 dark:text-slate-400">Send <strong class="text-slate-900 dark:text-white">$${amount.toFixed(2)}</strong> to:</p>
                <p class="mt-2 font-mono text-slate-900 dark:text-white">${escapeHtml(paypalEmail || 'Not configured')}</p>
            </div>
        `;
    } else {
        detailsHtml = `
            <div class="rounded-xl border border-slate-200 dark:border-slate-800 p-4">
                <p class="text-sm text-slate-600 dark:text-slate-400">Payment method details not available.</p>
            </div>
        `;
    }

    return `
        <div class="space-y-4">
            <div class="flex items-center justify-between gap-3">
                <div class="min-w-0">
                    <p class="font-bold text-slate-900 dark:text-white truncate">${escapeHtml(method.method_name || 'Payment Method')}</p>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Amount due: <strong class="text-slate-900 dark:text-white">$${amount.toFixed(2)}</strong></p>
                </div>
                <button onclick="backToPaymentSelection()" class="text-sm font-semibold text-slate-600 dark:text-slate-300 hover:text-primary">Change</button>
            </div>
            ${detailsHtml}
            <div class="rounded-xl border border-amber-200 dark:border-amber-900 bg-amber-50 dark:bg-amber-900/20 p-4">
                <p class="text-sm text-slate-800 dark:text-slate-200">
                    <strong>Note:</strong> Payment will be approved once received by the admin.
                </p>
            </div>
        </div>
    `;
}

function renderPaymentConfirmed() {
    return `
        <div class="space-y-4">
            <div class="rounded-xl border border-green-200 dark:border-green-900 bg-green-50 dark:bg-green-900/20 p-5">
                <p class="font-bold text-slate-900 dark:text-white">Payment submitted</p>
                <p class="text-sm text-slate-600 dark:text-slate-400 mt-1">Your trust has been created. Payment will be approved once received by the admin.</p>
            </div>
            <button onclick="doneToDashboard()" class="w-full bg-primary hover:opacity-90 text-white font-bold py-3 px-5 rounded-xl shadow">
                Done — Go to Dashboard
            </button>
        </div>
    `;
}

async function confirmPaymentAndCreateTrust() {
    onboardingData.payment_confirmed = true;
    saveOnboardingToStorage();
    const result = await createTrust({ redirect: false });
    if (result && result.success) {
        onboardingData.payment_stage = 'confirmed';
        onboardingData.created_trust_id = result.trust_id || null;
        saveOnboardingToStorage();
        loadStep(4);
    }
}

function doneToDashboard() {
    clearOnboardingStorage();
    window.location.href = '../dashboard/user/dashboard.php';
}

async function completeFreeCheckout() {
    onboardingData.payment_confirmed = false;
    onboardingData.payment_stage = 'select';
    saveOnboardingToStorage();
    await createTrust({ redirect: true });
}

function copyToClipboard(text, methodId) {
    navigator.clipboard.writeText(text).then(() => {
        const feedback = document.getElementById(`copyFeedback_${methodId}`);
        if (feedback) {
            feedback.classList.remove('hidden');
            setTimeout(() => {
                feedback.classList.add('hidden');
            }, 2000);
        }
        // Fallback notification
        showToast('Wallet address copied to clipboard!', 'success');
    }).catch(err => {
        console.error('Failed to copy:', err);
        showToast('Failed to copy address', 'error');
    });
}

function showToast(message, type = 'info') {
    // Simple toast notification
    const toast = document.createElement('div');
    toast.className = `fixed top-4 right-4 px-4 py-3 rounded-lg shadow-lg z-50 ${
        type === 'success' ? 'bg-green-500 text-white' : 
        type === 'error' ? 'bg-red-500 text-white' : 
        'bg-blue-500 text-white'
    }`;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

function escapeHtml(text) {
    if (typeof text !== 'string') return text;
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function nextStep() {
    if (currentStep < 4) {
        saveOnboardingToStorage();
        window.location.href = `onboarding.php?step=${currentStep + 1}${trustId ? '&trust_id=' + trustId : ''}`;
    }
}

function previousStep() {
    if (currentStep > 1) {
        saveOnboardingToStorage();
        window.location.href = `onboarding.php?step=${currentStep - 1}${trustId ? '&trust_id=' + trustId : ''}`;
    }
}

// Clear storage when user navigates away from onboarding (Cancel button, home page, etc.)
function handleCancelOrExit() {
    clearOnboardingStorage();
}

async function createTrust(options = { redirect: true }) {
    if (!onboardingData.trust_service_id) {
        alert('Error: Please select a trust type first.');
        window.location.href = 'onboarding.php?step=1';
        return;
    }
    
    const selectedService = getSelectedTrustService();
    const price = selectedService ? (selectedService.is_free ? 0.00 : parseFloat(selectedService.price || 0)) : 0.00;
    const isFree = !selectedService || !!selectedService.is_free || price <= 0;
    
    if (!isFree && !onboardingData.payment_method_id) {
        alert('Please select a payment method to continue.');
        return;
    }
    
    // Validate all required data
    if (!onboardingData.personal_info || !onboardingData.personal_info.full_name) {
        alert('Please complete all required information.');
        window.location.href = 'onboarding.php?step=2';
        return;
    }
    
    if (!onboardingData.beneficiaries || onboardingData.beneficiaries.length === 0) {
        alert('Please add at least one beneficiary.');
        window.location.href = 'onboarding.php?step=3';
        return;
    }
    
    const totalAllocation = onboardingData.beneficiaries.reduce((sum, ben) => sum + (parseFloat(ben.allocation) || 0), 0);
    if (Math.abs(totalAllocation - 100) > 0.01) {
        alert('Total allocation must equal 100%. Current total: ' + totalAllocation.toFixed(2) + '%');
        window.location.href = 'onboarding.php?step=3';
        return;
    }
    
    // Ensure user is logged in before creating trust
    if (!isLoggedIn) {
        alert('Please complete registration first. Redirecting...');
        window.location.href = 'onboarding.php?step=2';
        return;
    }
    
    try {
        // Get CSRF token (api/session.php always returns JSON including csrf_token)
        let csrfToken = null;
        try {
            const csrfResponse = await fetch('../api/session.php');
            const csrfData = await csrfResponse.json();
            if (csrfData && csrfData.csrf_token) csrfToken = csrfData.csrf_token;
        } catch (e) {
            console.warn('Could not fetch CSRF token:', e);
        }
        
        const requestBody = {
            trust_service_id: onboardingData.trust_service_id,
            payment_method_id: isFree ? null : onboardingData.payment_method_id,
            trust_data: {
                personal_info: onboardingData.personal_info,
                beneficiaries: onboardingData.beneficiaries,
                payment_info: isFree ? {
                    type: 'free',
                    amount: 0,
                } : {
                    payment_method_id: onboardingData.payment_method_id,
                    payment_method_type: onboardingData.payment_method,
                    amount: price,
                    user_confirmed: !!onboardingData.payment_confirmed,
                    confirmed_at: new Date().toISOString(),
                }
            }
        };
        
        if (csrfToken) {
            requestBody.csrf_token = csrfToken;
        }
        
        console.log('Creating trust with payload:', requestBody);
        
        const response = await fetch('../api/user/trusts.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(requestBody)
        });
        
        const responseText = await response.text();
        console.log('API Response status:', response.status);
        console.log('API Response text:', responseText);
        
        let data;
        try {
            data = JSON.parse(responseText);
        } catch (parseError) {
            console.error('Failed to parse API response as JSON:', parseError);
            console.error('Response was:', responseText);
            alert('Server returned invalid response. Please check console for details.');
            return { success: false };
        }
        
        if (data.success) {
            onboardingData.created_trust_id = data.trust?.id || null;
            
            // Clear storage after successful trust creation
            clearOnboardingStorage();
            
            if (options && options.redirect) {
                window.location.href = '../dashboard/user/dashboard.php';
            }
            return { success: true, trust_id: onboardingData.created_trust_id };
        } else {
            const errorMsg = data.message || data.error_details || 'Unknown error';
            console.error('Trust creation failed:', data);
            alert('Failed to create trust: ' + errorMsg);
            return { success: false };
        }
    } catch (error) {
        console.error('Error creating trust:', error);
        console.error('Error stack:', error.stack);
        alert('An error occurred while creating trust: ' + (error.message || 'Unknown error') + '. Please check console for details.');
        return { success: false };
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Password visibility toggle function
function togglePasswordVisibility(inputId, button) {
    const input = document.getElementById(inputId);
    const icon = button.querySelector('.toggle-password-icon');
    
    if (input && icon) {
        if (input.type === 'password') {
            input.type = 'text';
            icon.textContent = 'visibility';
        } else {
            input.type = 'password';
            icon.textContent = 'visibility_off';
        }
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', async () => {
    // Restore onboarding state ONLY if continuing from step 2+ (not step 1)
    // Step 1 always starts fresh
    loadOnboardingFromStorage();
    
    // Only prefill from profile if logged in AND on step 2+ (not step 1)
    // This prevents auto-filling when user wants to start fresh
    if (currentStep > 1) {
        await prefillPersonalInfoFromProfile();
    }
    
    // Load trust services first
    await loadTrustServices();
    
    loadStep(currentStep);
    
    // Disable next button if trust type not selected on step 1
    if (currentStep === 1 && !onboardingData.trust_type) {
        const nextBtn = document.getElementById('nextBtn');
        if (nextBtn) nextBtn.disabled = true;
    }
});

// Clear storage when user leaves the onboarding page (browser navigation, close tab, etc.)
window.addEventListener('beforeunload', function() {
    // Only clear if navigating away from onboarding (not just reloading)
    if (!window.location.pathname.includes('onboarding.php')) {
        clearOnboardingStorage();
    }
});

// Also clear on visibility change if user switches tabs/apps for too long
let visibilityTimeout = null;
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        // User switched away - set timeout to clear after 30 minutes of inactivity
        visibilityTimeout = setTimeout(() => {
            if (document.hidden) {
                clearOnboardingStorage();
            }
        }, 30 * 60 * 1000); // 30 minutes
    } else {
        // User came back - clear the timeout
        if (visibilityTimeout) {
            clearTimeout(visibilityTimeout);
            visibilityTimeout = null;
        }
    }
});
</script>
</body>
</html>
