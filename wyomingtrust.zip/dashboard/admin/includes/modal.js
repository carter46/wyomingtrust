/**
 * Reusable Modal Component for Admin Dashboard
 * Replaces browser alerts, confirms, and prompts with styled modals
 */

// Modal container element
let modalContainer = null;

/**
 * Initialize modal system
 */
function initModalSystem() {
    if (modalContainer) return;
    
    modalContainer = document.createElement('div');
    modalContainer.id = 'modalContainer';
    modalContainer.className = 'fixed inset-0 z-50 hidden';
    modalContainer.innerHTML = `
        <div class="modal-backdrop fixed inset-0 bg-black/50 transition-opacity" onclick="closeModal()"></div>
        <div class="modal-content fixed inset-0 flex items-center justify-center p-4 pointer-events-none">
            <div class="modal-dialog bg-white dark:bg-navy-800 rounded-xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto pointer-events-auto transform transition-all" style="opacity: 0; transform: scale(0.95);">
                <div class="modal-header flex items-center justify-between p-6 border-b border-slate-200 dark:border-slate-700">
                    <h3 class="modal-title text-xl font-bold text-navy-900 dark:text-white"></h3>
                    <button onclick="closeModal()" class="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors">
                        <span class="material-icons-outlined">close</span>
                    </button>
                </div>
                <div class="modal-body p-6"></div>
                <div class="modal-footer flex items-center justify-end gap-3 p-6 border-t border-slate-200 dark:border-slate-700"></div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modalContainer);
    
    // Close on ESC key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && !modalContainer.classList.contains('hidden')) {
            closeModal();
        }
    });
}

/**
 * Show a generic modal
 * @param {string} title - Modal title
 * @param {string} content - HTML content for modal body
 * @param {Array} actions - Array of action buttons [{label, onclick, class, icon}]
 */
function showModal(title, content, actions = []) {
    initModalSystem();
    
    const dialog = modalContainer.querySelector('.modal-dialog');
    modalContainer.querySelector('.modal-title').textContent = title;
    modalContainer.querySelector('.modal-body').innerHTML = content;
    
    const footer = modalContainer.querySelector('.modal-footer');
    footer.innerHTML = '';
    
    if (actions.length === 0) {
        // Default close button
        footer.innerHTML = `
            <button onclick="closeModal()" class="px-4 py-2 bg-primary text-navy-900 font-semibold rounded-lg hover:opacity-90 transition-opacity">
                Close
            </button>
        `;
    } else {
        actions.forEach(action => {
            const button = document.createElement('button');
            button.className = action.class || 'px-4 py-2 rounded-lg font-semibold transition-opacity hover:opacity-90';
            button.innerHTML = action.icon ? `<span class="material-icons-outlined text-sm mr-2">${action.icon}</span>${action.label}` : action.label;
            button.onclick = action.onclick;
            footer.appendChild(button);
        });
    }
    
    modalContainer.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
    
    // Animate in
    setTimeout(() => {
        dialog.style.opacity = '1';
        dialog.style.transform = 'scale(1)';
    }, 10);
}

/**
 * Show a confirmation modal
 * @param {string} title - Modal title
 * @param {string} message - Confirmation message
 * @param {Function} onConfirm - Callback when confirmed
 * @param {Function} onCancel - Optional callback when cancelled
 */
function showConfirmModal(title, message, onConfirm, onCancel = null) {
    const content = `
        <div class="flex items-start gap-4">
            <div class="flex-shrink-0 w-12 h-12 bg-amber-100 dark:bg-amber-900/30 rounded-full flex items-center justify-center">
                <span class="material-icons-outlined text-amber-600 dark:text-amber-400 text-2xl">warning</span>
            </div>
            <div class="flex-1">
                <p class="text-slate-700 dark:text-slate-300">${escapeHtml(message)}</p>
            </div>
        </div>
    `;
    
    const actions = [
        {
            label: 'Cancel',
            onclick: () => {
                closeModal();
                if (onCancel) onCancel();
            },
            class: 'px-4 py-2 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold rounded-lg hover:opacity-90 transition-opacity'
        },
        {
            label: 'Confirm',
            onclick: () => {
                closeModal();
                if (onConfirm) onConfirm();
            },
            class: 'px-4 py-2 bg-red-600 text-white font-semibold rounded-lg hover:opacity-90 transition-opacity',
            icon: 'check'
        }
    ];
    
    showModal(title, content, actions);
}

/**
 * Show a form modal
 * @param {string} title - Modal title
 * @param {string} formHtml - HTML form content
 * @param {Function} onSubmit - Callback when form is submitted (receives form data object)
 * @param {Function} onCancel - Optional callback when cancelled
 */
function showFormModal(title, formHtml, onSubmit, onCancel = null) {
    const content = `
        <form id="modalForm" onsubmit="event.preventDefault(); handleFormSubmit(event);" class="space-y-4">
            ${formHtml}
        </form>
    `;
    
    // Store callbacks in modal container
    modalContainer.dataset.onSubmit = JSON.stringify({ hasCallback: !!onSubmit });
    modalContainer._onSubmit = onSubmit;
    modalContainer._onCancel = onCancel;
    
    const actions = [
        {
            label: 'Cancel',
            onclick: () => {
                closeModal();
                if (onCancel) onCancel();
            },
            class: 'px-4 py-2 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold rounded-lg hover:opacity-90 transition-opacity'
        },
        {
            label: 'Submit',
            onclick: () => {
                const form = document.getElementById('modalForm');
                if (form.checkValidity()) {
                    handleFormSubmit(new Event('submit'));
                } else {
                    form.reportValidity();
                }
            },
            class: 'px-4 py-2 bg-primary text-navy-900 font-semibold rounded-lg hover:opacity-90 transition-opacity',
            icon: 'check'
        }
    ];
    
    showModal(title, content, actions);
}

/**
 * Handle form submission
 */
function handleFormSubmit(event) {
    event.preventDefault();
    const form = document.getElementById('modalForm');
    const formData = new FormData(form);
    const data = {};
    
    // Convert FormData to object
    for (let [key, value] of formData.entries()) {
        data[key] = value;
    }
    
    // Also check for checkboxes and radio buttons
    const inputs = form.querySelectorAll('input, textarea, select');
    inputs.forEach(input => {
        if (input.type === 'checkbox') {
            data[input.name] = input.checked;
        } else if (input.type === 'radio' && input.checked) {
            data[input.name] = input.value;
        } else if (!data[input.name] && input.value) {
            data[input.name] = input.value;
        }
    });
    
    closeModal();
    if (modalContainer._onSubmit) {
        modalContainer._onSubmit(data);
    }
}

/**
 * Close the current modal
 */
function closeModal() {
    if (!modalContainer) return;
    
    const dialog = modalContainer.querySelector('.modal-dialog');
    dialog.style.opacity = '0';
    dialog.style.transform = 'scale(0.95)';
    
    setTimeout(() => {
        modalContainer.classList.add('hidden');
        document.body.style.overflow = '';
        
        // Clear callbacks
        delete modalContainer._onSubmit;
        delete modalContainer._onCancel;
    }, 200);
}

/**
 * Show a toast notification
 * @param {string} message - Toast message
 * @param {string} type - 'success', 'error', 'info', 'warning'
 * @param {number} duration - Duration in milliseconds (default 5000)
 */
function showToast(message, type = 'info', duration = 5000) {
    const toast = document.createElement('div');
    const icons = {
        success: 'check_circle',
        error: 'error',
        info: 'info',
        warning: 'warning'
    };
    
    const colors = {
        success: 'bg-green-50 dark:bg-green-900/20 border-green-400 text-green-700 dark:text-green-400',
        error: 'bg-red-50 dark:bg-red-900/20 border-red-400 text-red-700 dark:text-red-400',
        info: 'bg-blue-50 dark:bg-blue-900/20 border-blue-400 text-blue-700 dark:text-blue-400',
        warning: 'bg-amber-50 dark:bg-amber-900/20 border-amber-400 text-amber-700 dark:text-amber-400'
    };
    
    toast.className = `fixed top-20 right-4 ${colors[type] || colors.info} border px-4 py-3 rounded-lg shadow-lg z-50 flex items-center gap-2 transform transition-all animate-slide-in`;
    toast.innerHTML = `
        <span class="material-icons-outlined text-sm">${icons[type] || icons.info}</span>
        <span>${escapeHtml(message)}</span>
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
    if (typeof text !== 'string') return text;
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Initialize on DOM ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initModalSystem);
} else {
    initModalSystem();
}
